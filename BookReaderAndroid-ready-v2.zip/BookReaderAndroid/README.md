# Book Reader Android

Android WebView wrapper for the Arabic/English PDF reader. Speech uses Android TextToSpeech directly, so it can use HayaiTTS/Kareem when HayaiTTS is selected as the phone's preferred TTS engine.

The HTML currently loads PDF.js and Tesseract.js from CDN, so Internet is required to load those web libraries and OCR resources. Native Android TTS itself can work offline after the HayaiTTS voice is installed.
