package com.bookreader.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.InputStream;

import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private String engineName = "Android TTS";
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("app.local".equals(uri.getHost())) {
                    String path = uri.getPath();
                    if (path == null || path.equals("/") || path.equals("/index.html")) path = "/index.html";
                    if (path.startsWith("/")) path = path.substring(1);
                    try {
                        InputStream in = getAssets().open(path);
                        String mime = "text/plain";
                        if (path.endsWith(".html")) mime = "text/html";
                        else if (path.endsWith(".js") || path.endsWith(".mjs")) mime = "text/javascript";
                        else if (path.endsWith(".css")) mime = "text/css";
                        else if (path.endsWith(".json")) mime = "application/json";
                        return new WebResourceResponse(mime, "UTF-8", in);
                    } catch (Exception ignored) {
                        return null;
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf"});
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidTTSBridge(), "AndroidTTS");
        webView.loadUrl("https://app.local/index.html");

        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true;
            try {
                engineName = tts.getDefaultEngine();
                if (engineName == null || engineName.isEmpty()) engineName = "Android TTS";
            } catch (Exception ignored) {}
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) { notifyDone(utteranceId); }
                @Override public void onError(String utteranceId) { notifyError(utteranceId, "TTS error"); }
                @Override public void onError(String utteranceId, int errorCode) { notifyError(utteranceId, "TTS error " + errorCode); }
            });
            runJs("if(window.refreshVoiceBadges) refreshVoiceBadges();");
        }
    }

    private void runJs(String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private String jsQuote(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    private void notifyDone(String id) {
        runJs("window.nativeTtsDone && window.nativeTtsDone('" + jsQuote(id) + "');");
    }

    private void notifyError(String id, String msg) {
        runJs("window.nativeTtsError && window.nativeTtsError('" + jsQuote(id) + "','" + jsQuote(msg) + "');");
    }

    public class AndroidTTSBridge {
        @JavascriptInterface public boolean isReady() { return ttsReady; }
        @JavascriptInterface public String getEngineName() { return engineName; }

        @JavascriptInterface
        public boolean speak(String text, String lang, float rate, String utteranceId) {
            if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) return false;
            try {
                Locale locale = "en".equalsIgnoreCase(lang) ? Locale.UK : new Locale("ar", "JO");
                tts.setLanguage(locale);
                tts.setSpeechRate(Math.max(0.3f, Math.min(rate, 2.5f)));
                Bundle params = new Bundle();
                int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
                return r == TextToSpeech.SUCCESS;
            } catch (Exception e) {
                notifyError(utteranceId, e.getMessage());
                return false;
            }
        }

        @JavascriptInterface public void stop() {
            if (tts != null) tts.stop();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    results = new Uri[]{uri};
                    try {
                        getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
