# Book Reader Android v3

Fixes the WebView JavaScript bootstrap by serving bundled assets from an internal HTTPS origin (https://app.local) instead of file://.

This fixes:
- PDF file selection updating book information
- PDF.js loading
- Android TTS / HayaiTTS status detection
- Read, stop, pause and next buttons

Build with Gradle :app:assembleDebug.
