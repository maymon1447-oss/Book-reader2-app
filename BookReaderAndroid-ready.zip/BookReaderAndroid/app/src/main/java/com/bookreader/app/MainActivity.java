package com.bookreader.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private WebView webView;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private String engineName = "Android TTS";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidTTSBridge(), "AndroidTTS");
        webView.loadUrl("file:///android_asset/index.html");

        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true;
            try {
                engineName = tts.getDefaultEngine();
                if (engineName == null || engineName.isEmpty()) engineName = "Android TTS";
            } catch (Exception ignored) {}
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) { notifyDone(utteranceId); }
                @Override public void onError(String utteranceId) { notifyError(utteranceId, "TTS error"); }
                @Override public void onError(String utteranceId, int errorCode) { notifyError(utteranceId, "TTS error " + errorCode); }
            });
            runJs("if(window.refreshVoiceBadges) refreshVoiceBadges();");
        }
    }

    private void runJs(String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    private String jsQuote(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
    }

    private void notifyDone(String id) {
        runJs("window.nativeTtsDone && window.nativeTtsDone('" + jsQuote(id) + "');");
    }

    private void notifyError(String id, String msg) {
        runJs("window.nativeTtsError && window.nativeTtsError('" + jsQuote(id) + "','" + jsQuote(msg) + "');");
    }

    public class AndroidTTSBridge {
        @JavascriptInterface public boolean isReady() { return ttsReady; }
        @JavascriptInterface public String getEngineName() { return engineName; }

        @JavascriptInterface
        public boolean speak(String text, String lang, float rate, String utteranceId) {
            if (!ttsReady || tts == null || text == null || text.trim().isEmpty()) return false;
            try {
                Locale locale = "en".equalsIgnoreCase(lang) ? Locale.UK : new Locale("ar", "JO");
                tts.setLanguage(locale);
                tts.setSpeechRate(Math.max(0.3f, Math.min(rate, 2.5f)));
                Bundle params = new Bundle();
                int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
                return r == TextToSpeech.SUCCESS;
            } catch (Exception e) {
                notifyError(utteranceId, e.getMessage());
                return false;
            }
        }

        @JavascriptInterface public void stop() {
            if (tts != null) tts.stop();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
